/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Building2, Landmark, Briefcase, ShieldCheck, CreditCard, FileText, 
  CheckCircle2, Calculator, Phone, Mail, MapPin, Menu, X, ArrowRight,
  MessageCircle, Zap, Star, Users, Percent, ChevronRight
} from 'lucide-react';

export default function App() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // EMI Calculator State
  const [loanAmount, setLoanAmount] = useState(500000);
  const [interestRate, setInterestRate] = useState(10.5);
  const [tenureYears, setTenureYears] = useState(5);
  const [emi, setEmi] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    calculateEMI();
  }, [loanAmount, interestRate, tenureYears]);

  const calculateEMI = () => {
    const r = interestRate / (12 * 100);
    const n = tenureYears * 12;
    if (r === 0) {
      setEmi(Math.round(loanAmount / n));
      return;
    }
    const emiValue = (loanAmount * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    setEmi(Math.round(emiValue));
  };

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Calculator', href: '#calculator' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <div className="min-h-screen relative overflow-hidden bg-slate-50 selection:bg-gold-500 selection:text-navy-900">
      
      {/* Navbar */}
      <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-md py-3' : 'bg-navy-900/90 backdrop-blur-md py-5'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className={`w-10 h-10 rounded flex items-center justify-center ${isScrolled ? 'bg-navy-900 text-gold-500' : 'bg-gold-500 text-navy-900'}`}>
              <Landmark className="w-6 h-6" />
            </div>
            <div className={`font-serif text-xl md:text-2xl font-bold tracking-tight ${isScrolled ? 'text-navy-900' : 'text-white'}`}>
              NEXORA
              <span className={isScrolled ? 'text-gold-600 block font-light text-base md:text-xl italic' : 'text-gold-500 block font-light text-base md:text-xl italic'}>
                Corporate Ventures
              </span>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className={`text-sm font-medium transition-colors hover:text-gold-500 ${isScrolled ? 'text-slate-600' : 'text-slate-200'}`}>
                {link.name}
              </a>
            ))}
            <a href="#contact" className={`px-5 py-2.5 rounded text-sm font-semibold transition-all ${isScrolled ? 'bg-navy-900 text-white hover:bg-navy-800' : 'bg-gold-500 text-navy-900 hover:bg-gold-400'}`}>
              Apply Now
            </a>
          </nav>

          <button className={`md:hidden p-2 ${isScrolled ? 'text-navy-900' : 'text-white'}`} onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
            {isMobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-navy-900 pt-24 px-6 md:hidden">
          <div className="flex flex-col gap-6 text-center">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className="text-xl text-white hover:text-gold-500 font-serif" onClick={() => setIsMobileMenuOpen(false)}>
                {link.name}
              </a>
            ))}
            <a href="#contact" className="mt-4 px-6 py-3 bg-gold-500 text-navy-900 rounded font-semibold text-lg max-w-xs mx-auto w-full" onClick={() => setIsMobileMenuOpen(false)}>
              Apply Now
            </a>
          </div>
        </div>
      )}

      {/* Hero Section */}
      <section id="home" className="relative pt-32 pb-20 md:pt-48 md:pb-32 bg-navy-900 text-white overflow-hidden">
        {/* Layered Gradient & Modern Fintech Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-navy-950 via-navy-900 to-navy-800"></div>
        <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-navy-600/30 rounded-full blur-[120px] mix-blend-screen animate-glow pointer-events-none"></div>
        <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-gold-500/20 rounded-full blur-[120px] mix-blend-screen animate-glow pointer-events-none" style={{ animationDelay: '2s' }}></div>
        {/* Subtle Financial Grid */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: "radial-gradient(circle at 1px 1px, rgba(255,255,255,0.15) 1px, transparent 0)", backgroundSize: "40px 40px" }}></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <div className="w-12 h-1 bg-gold-400 mb-6 rounded-full shadow-[0_0_10px_rgba(197,160,42,0.6)]"></div>
              <div className="inline-flex items-center gap-2 py-1.5 px-4 rounded-full glass-panel text-gold-300 text-xs md:text-sm font-semibold tracking-wider uppercase mb-6 shadow-[0_0_15px_rgba(197,160,42,0.15)] border border-gold-500/30">
                <Zap className="w-4 h-4 fill-gold-400 text-gold-400" />
                India's Top Banks & NBFCs
              </div>
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
              className="font-serif text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-6 tracking-tight drop-shadow-lg"
            >
              Your Trusted <span className="text-gold-400 relative inline-block">Financial Partner<div className="absolute -bottom-2 left-0 w-full h-[3px] bg-gradient-to-r from-gold-400 to-transparent opacity-60 rounded-full"></div></span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl leading-relaxed font-light"
            >
              Premium consultancy for Personal Loans, Home Loans, Insurance, and Business Finance. Connect with India's leading banks seamlessly securely.
            </motion.p>
            <motion.div 
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row gap-4"
            >
              <a href="#contact" className="px-8 py-4 bg-gradient-to-r from-gold-500 to-gold-400 hover:from-gold-400 hover:to-gold-300 text-navy-950 font-bold shadow-[0_4px_20px_rgba(197,160,42,0.4)] rounded-full flex items-center justify-center gap-2 transition-all transform hover:-translate-y-1 text-sm uppercase tracking-wide">
                Apply Now <ArrowRight className="w-5 h-5" />
              </a>
              <a href="#services" className="px-8 py-4 border-2 border-white/20 hover:border-white/40 hover:bg-white/5 text-white font-bold rounded-full flex items-center justify-center transition-all text-sm uppercase tracking-wide backdrop-blur-sm">
                Explore Services
              </a>
            </motion.div>
          </div>
        </div>
        
        {/* Decorative Trust Badge */}
        <div className="hidden lg:flex absolute right-12 bottom-12 items-center gap-4 glass-panel p-4 rounded-2xl shadow-2xl overflow-hidden group">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-[150%] group-hover:translate-x-[150%] transition-transform duration-1000 ease-in-out"></div>
          <div className="bg-gradient-to-br from-gold-400 to-gold-600 p-3 rounded-full text-navy-950 shadow-[0_0_15px_rgba(197,160,42,0.4)]">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <p className="font-bold text-xl text-white tracking-tight">Regulated</p>
            <p className="text-sm text-gold-300 font-medium">NBFC Partner</p>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section id="about" className="py-20 lg:py-32 bg-slate-50 relative overflow-hidden">
        {/* Decorative subtle gradient background blob */}
        <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-navy-900/5 rounded-full blur-[100px] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="aspect-[4/5] rounded-2xl overflow-hidden shrink-0 shadow-[0_20px_50px_rgba(10,30,59,0.1)] border border-slate-200">
                <img 
                  src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?auto=format&fit=crop&q=80&w=1000" 
                  alt="Indian Financial Consultation" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-8 -right-8 bg-gradient-to-br from-navy-900 to-navy-800 text-white p-8 rounded-xl shadow-2xl hidden md:block max-w-xs border border-white/10">
                <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4wNykiIHN0cm9rZS13aWR0aD0iMSIvPgo8L3N2Zz4=')] opacity-50 rounded-xl pointer-events-none"></div>
                <Building2 className="w-10 h-10 text-gold-400 mb-4" />
                <h4 className="font-serif text-xl font-bold mb-2">Trusted Nationwide</h4>
                <p className="text-sm text-slate-300 font-light">Helping customers across India secure fast loan approvals from premium institutions.</p>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
            >
              <span className="text-gold-600 font-bold tracking-wider uppercase text-sm mb-4 block">About Us</span>
              <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy-900 mb-6 leading-tight">
                Empowering Your Financial Future
              </h2>
              <div className="h-1 w-20 bg-gold-500 mb-8 rounded"></div>
              <p className="text-lg text-slate-600 mb-6 leading-relaxed">
                <strong className="text-navy-900">Nexora Corporate Services</strong> is a growing financial consultancy helping customers access banking and financial products easily and professionally. 
              </p>
              <p className="text-slate-600 mb-8 leading-relaxed">
                We believe in simplifying the complex world of finance. Whether you need a personal loan for immediate needs, a business loan to scale your operations, or comprehensive insurance coverage, we act as your trusted bridge to India's top financial institutions.
              </p>

              <div className="grid sm:grid-cols-2 gap-6 mb-10">
                <div className="flex items-start gap-4">
                  <div className="bg-slate-100 p-2 rounded text-navy-900">
                    <Star className="w-5 h-5 fill-gold-500 text-gold-500" />
                  </div>
                  <div>
                    <h5 className="font-bold text-navy-900 mb-1">Expert Guidance</h5>
                    <p className="text-sm text-slate-600">Tailored financial advice.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-slate-100 p-2 rounded text-navy-900">
                    <Users className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="font-bold text-navy-900 mb-1">Dedicated Support</h5>
                    <p className="text-sm text-slate-600">We stay with you every step.</p>
                  </div>
                </div>
              </div>

              <a href="#contact" className="inline-flex items-center gap-2 text-navy-900 font-bold hover:text-gold-600 transition-colors">
                Speak to our consultants <ChevronRight className="w-5 h-5" />
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 lg:py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="text-gold-600 font-bold tracking-wider uppercase text-sm mb-4 block">What We Offer</span>
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy-900 mb-6">Comprehensive Financial Solutions</h2>
            <div className="h-1 w-20 bg-gold-500 mx-auto rounded"></div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { title: "Personal Loan", icon: <Briefcase />, desc: "Fast unsecured loans for medical emergencies, travel, weddings, or any immediate personal requirements." },
              { title: "Home Loan & LAP", icon: <Building2 />, desc: "Turn your dream home into reality or leverage your property for a Loan Against Property." },
              { title: "Business Loan", icon: <Landmark />, desc: "Scale your business with collateral-free funding options, working capital, and term loans." },
              { title: "Credit Card", icon: <CreditCard />, desc: "Get tailored credit cards from top banks with premium rewards, cashback, and lounge access." },
              { title: "Insurance Services", icon: <ShieldCheck />, desc: "Secure your family and assets with comprehensive Health, Life, and General Insurance plans." },
              { title: "GST & Documentation", icon: <FileText />, desc: "End-to-end support for GST registration, filing, and essential financial document drafting." },
            ].map((service, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: index * 0.1 }}
                whileHover={{ y: -8 }}
                className="bg-white p-8 rounded-2xl shadow-[0_4px_24px_rgba(0,0,0,0.04)] border border-slate-100 hover:border-gold-400 hover:shadow-[0_12px_40px_rgba(10,30,59,0.08)] transition-all duration-300 group relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-gold-500 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="w-14 h-14 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center text-navy-900 group-hover:bg-gradient-to-br group-hover:from-navy-900 group-hover:to-navy-800 group-hover:text-gold-400 transition-all mb-6 shadow-sm">
                  {React.cloneElement(service.icon, { className: 'w-7 h-7' })}
                </div>
                <h3 className="font-serif text-2xl font-bold text-navy-900 mb-2">{service.title}</h3>
                <p className="text-slate-600 leading-relaxed mb-6 font-light">{service.desc}</p>
                <a href="#contact" className="text-sm font-bold text-navy-900 group-hover:text-gold-600 flex items-center gap-1 transition-colors uppercase tracking-wider">
                  Learn more <ArrowRight className="w-4 h-4 ml-1" />
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 lg:py-32 bg-navy-900 text-white relative overflow-hidden">
        {/* Layered Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-tr from-navy-950 via-navy-900 to-navy-800"></div>
        <div className="absolute right-[-20%] bottom-[-20%] w-[800px] h-[800px] bg-gold-600/10 rounded-full blur-[150px] pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <span className="inline-block py-1 px-3 rounded-full bg-gold-500/10 text-gold-400 text-xs font-semibold tracking-wider uppercase mb-6 border border-gold-500/20">The Nexora Advantage</span>
              <h2 className="font-serif text-3xl md:text-5xl font-bold mb-8 leading-tight tracking-tight drop-shadow-md">Why Customers Trust Our Financial Services</h2>
              
              <div className="space-y-6">
                {[
                  { title: "Fast Processing", desc: "We ensure rapid document verification and quick disbursals.", icon: <Zap className="text-gold-400" /> },
                  { title: "Trusted Banking Partners", desc: "Associated with India's most reputed Banks and NBFCs.", icon: <Landmark className="text-gold-400" /> },
                  { title: "Secure Documentation", desc: "Hassle-free paperwork handled securely by our expert team.", icon: <FileText className="text-gold-400" /> },
                  { title: "PAN India Services", desc: "Serving clients from Odisha to every corner of the country.", icon: <MapPin className="text-gold-400" /> },
                  { title: "No Hidden Charges", desc: "100% transparency in our proceedings and fees.", icon: <Percent className="text-gold-400" /> },
                  { title: "Dedicated Customer Support", desc: "We are always one call away to resolve your queries.", icon: <Phone className="text-gold-400" /> }
                ].map((item, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.4, delay: index * 0.1 }}
                    className="flex gap-4 group"
                  >
                    <div className="mt-1 bg-white/5 border border-white/10 p-3 rounded-lg shrink-0 h-fit group-hover:bg-white/10 transition-colors shadow-inner">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="text-lg font-bold text-gold-300 mb-1 group-hover:text-gold-400 transition-colors">{item.title}</h4>
                      <p className="text-slate-300/80 text-sm leading-relaxed font-light">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <div className="aspect-square md:aspect-[4/3] lg:aspect-square bg-gold-400/20 rounded-full absolute -inset-10 blur-3xl z-0 animate-glow"></div>
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }} transition={{ duration: 0.6 }}
                className="relative z-10 glass-card rounded-2xl p-8 backdrop-blur-xl border border-white/20"
              >
                <div className="text-center mb-8">
                  <h3 className="font-serif text-3xl font-bold text-navy-900 tracking-tight">Approval Success Rate</h3>
                  <p className="text-slate-500 mt-2 font-light">Consistent funding across personal & corporate portfolios.</p>
                </div>
                
                <div className="flex items-center justify-center mb-8">
                  <div className="w-56 h-56 rounded-full border-[10px] border-slate-100/50 flex items-center justify-center relative shadow-inner">
                    <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                      <circle cx="50%" cy="50%" r="46%" fill="transparent" stroke="url(#goldGradient)" strokeWidth="10" strokeDasharray="290" strokeDashoffset="20"></circle>
                      <defs>
                        <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="var(--color-gold-400)" />
                          <stop offset="100%" stopColor="var(--color-gold-600)" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="text-center">
                      <span className="text-5xl font-bold text-navy-900 block drop-shadow-sm">95%</span>
                      <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mt-1 block">Approvals</span>
                    </div>
                  </div>
                </div>
                
                <p className="text-center text-sm font-medium text-slate-700 bg-slate-50 rounded-xl p-5 border border-slate-200/60 shadow-sm">
                  Our strong Indian banking ties allow us to securely negotiate the best possible terms for you.
                </p>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* EMI Calculator */}
      <section id="calculator" className="py-20 lg:py-32 bg-slate-50 relative overflow-hidden">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: "linear-gradient(to right, #0A1E3B 1px, transparent 1px), linear-gradient(to bottom, #0A1E3B 1px, transparent 1px)", backgroundSize: "40px 40px" }}></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <span className="inline-block py-1 px-3 rounded-full bg-slate-200 text-navy-700 text-xs font-semibold tracking-wider uppercase mb-6 border border-slate-300">Financial Planning</span>
            <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy-900 mb-6 tracking-tight">EMI Calculator</h2>
            <div className="h-1 w-20 bg-gold-500 mx-auto rounded mb-6"></div>
            <p className="text-slate-600 text-lg font-light">Use our advanced EMI calculator to estimate your monthly loan repayment.</p>
          </div>

          <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-[0_8px_40px_rgba(10,30,59,0.08)] overflow-hidden border border-slate-200">
            <div className="grid md:grid-cols-5 h-full">
              
              <div className="md:col-span-3 p-8 lg:p-12 border-r border-slate-100 bg-white">
                
                <div className="mb-10">
                  <div className="flex justify-between mb-4">
                    <label className="font-bold text-navy-900">Loan Amount</label>
                    <span className="font-bold text-gold-600 bg-gold-400/10 px-3 py-1 rounded-md">₹ {loanAmount.toLocaleString('en-IN')}</span>
                  </div>
                  <input 
                    type="range" min="50000" max="10000000" step="50000"
                    value={loanAmount} onChange={(e) => setLoanAmount(Number(e.target.value))}
                    className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-navy-900"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium uppercase">
                    <span>₹50K</span>
                    <span>₹1Cr</span>
                  </div>
                </div>

                <div className="mb-10">
                  <div className="flex justify-between mb-4">
                    <label className="font-bold text-navy-900">Interest Rate (p.a.)</label>
                    <span className="font-bold text-gold-600 bg-gold-400/10 px-3 py-1 rounded-md">{interestRate}%</span>
                  </div>
                  <input 
                    type="range" min="5" max="25" step="0.1"
                    value={interestRate} onChange={(e) => setInterestRate(Number(e.target.value))}
                    className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-navy-900"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium uppercase">
                    <span>5%</span>
                    <span>25%</span>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-4">
                    <label className="font-bold text-navy-900">Loan Tenure</label>
                    <span className="font-bold text-gold-600 bg-gold-400/10 px-3 py-1 rounded-md">{tenureYears} Years</span>
                  </div>
                  <input 
                    type="range" min="1" max="30" step="1"
                    value={tenureYears} onChange={(e) => setTenureYears(Number(e.target.value))}
                    className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-navy-900"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium uppercase">
                    <span>1 Yr</span>
                    <span>30 Yrs</span>
                  </div>
                </div>
              </div>

              <div className="md:col-span-2 bg-gradient-to-br from-navy-950 to-navy-800 text-white p-8 lg:p-12 flex flex-col justify-center relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxwYXRoIGQ9Ik0gNDAgMCBMIDAgMCAwIDQwIiBmaWxsPSJub25lIiBzdHJva2U9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIgc3Ryb2tlLXdpZHRoPSIxIi8+Cjwvc3ZnPg==')] pointer-events-none"></div>
                <div className="absolute top-0 right-0 p-8 opacity-[0.03]">
                  <Calculator className="w-48 h-48" />
                </div>
                <div className="relative z-10">
                  <h4 className="text-slate-400 font-medium mb-2 uppercase tracking-wide text-xs">Estimated Monthly EMI</h4>
                  <div className="font-serif text-4xl lg:text-5xl font-bold text-gold-400 mb-8 break-words drop-shadow-md">
                    ₹ {emi.toLocaleString('en-IN')}
                  </div>

                  <div className="space-y-5 mb-10 pt-8 border-t border-white/10">
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1 font-bold">Principal Amount</p>
                      <p className="font-bold text-lg text-white">₹ {loanAmount.toLocaleString('en-IN')}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-slate-400 uppercase tracking-widest mb-1 font-bold">Total Interest</p>
                      <p className="font-bold text-lg text-white">₹ {((emi * tenureYears * 12) - loanAmount).toLocaleString('en-IN')}</p>
                    </div>
                  </div>

                  <a href="#contact" className="block text-center w-full bg-gradient-to-r from-gold-500 to-gold-400 hover:from-gold-400 hover:to-gold-300 text-navy-950 font-bold py-3 md:py-4 rounded-xl transition-all shadow-[0_4px_15px_rgba(197,160,42,0.4)] uppercase text-sm tracking-wide">
                    Apply for this Loan
                  </a>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-slate-50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-navy-900 mb-4 tracking-tight">What Our Clients Say</h2>
            <div className="h-1 w-16 bg-gold-500 mx-auto rounded"></div>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { text: "Nexora Corporate Ventures made my home loan process incredibly smooth. Their team handled all the complex paperwork and secured a great interest rate for me.", author: "Rajesh Mohanty", role: "Business Owner" },
              { text: "I needed a fast personal loan for a medical emergency. The consultants here were highly responsive and got it approved within 48 hours without hidden fees.", author: "Sunita Dash", role: "IT Professional" },
              { text: "Excellent DSA services. They not only assisted with my business loan but also guided me securely through my GST registration. A true one-stop solution.", author: "Vikram Singh", role: "Entrepreneur" }
            ].map((testi, idx) => (
              <motion.div key={idx} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }} className="bg-white p-8 rounded-2xl shadow-[0_4px_24px_rgba(0,0,0,0.03)] border border-slate-100 hover:shadow-lg transition-shadow relative">
                <div className="absolute top-0 right-8 w-12 h-1 bg-gold-400 rounded-b-lg"></div>
                <div className="flex gap-1 mb-6 text-gold-500">
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <p className="text-slate-600 italic mb-8 font-light relative z-10">"{testi.text}"</p>
                <div className="flex items-center gap-4 border-t border-slate-100 pt-4">
                  <div className="w-10 h-10 rounded-full bg-navy-900 text-gold-400 flex items-center justify-center font-bold font-serif text-lg">
                    {testi.author.charAt(0)}
                  </div>
                  <div>
                    <h5 className="font-bold text-navy-900 text-sm tracking-wide">{testi.author}</h5>
                    <p className="text-[11px] uppercase tracking-wider text-slate-500 font-semibold">{testi.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 lg:py-32 bg-white relative overflow-hidden">
        <div className="absolute top-[-50%] left-[-20%] w-[800px] h-[800px] bg-slate-50 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <span className="inline-block py-1 px-3 rounded-full bg-slate-100 text-slate-600 text-xs font-semibold tracking-wider uppercase mb-6 border border-slate-200">Get In Touch</span>
              <h2 className="font-serif text-3xl md:text-5xl font-bold text-navy-900 mb-6 tracking-tight">Ready to achieve your financial goals?</h2>
              <p className="text-lg text-slate-600 mb-10 font-light">Fill out the form and our financial expert will connect with you shortly to discuss the best solutions available.</p>
              
              <div className="space-y-8">
                <div className="flex items-start gap-4">
                  <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-navy-900 shadow-sm">
                    <Phone className="w-6 h-6 outline-none text-gold-500" />
                  </div>
                  <div className="pt-1">
                    <h5 className="font-bold text-navy-900 mb-1 text-sm uppercase tracking-wide">Phone & WhatsApp</h5>
                    <p className="text-slate-600 font-medium">+91 70779 26565</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-navy-900 shadow-sm">
                    <Mail className="w-6 h-6 text-gold-500" />
                  </div>
                  <div className="pt-1">
                    <h5 className="font-bold text-navy-900 mb-1 text-sm uppercase tracking-wide">Email Address</h5>
                    <p className="text-slate-600 font-medium">nexoracorporateventures@gmail.com</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl text-navy-900 shadow-sm">
                    <MapPin className="w-6 h-6 text-gold-500" />
                  </div>
                  <div className="pt-1">
                    <h5 className="font-bold text-navy-900 mb-1 text-sm uppercase tracking-wide">Office Location</h5>
                    <p className="text-slate-600 max-w-xs font-light">Serving clients majorly in Odisha and proudly across India.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-navy-950 to-navy-800 rounded-3xl p-8 lg:p-10 shadow-[0_20px_50px_rgba(10,30,59,0.15)] relative overflow-hidden border border-white/5">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gold-400/10 rounded-full blur-[80px] pointer-events-none"></div>
              <h3 className="font-serif text-2xl font-bold text-white mb-8 tracking-wide">Request a Callback</h3>
              <form onSubmit={(e) => e.preventDefault()} className="space-y-6 relative z-10">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Full Name</label>
                  <input type="text" placeholder="John Doe" className="w-full bg-navy-900/50 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-slate-600 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-light" />
                </div>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Phone Number</label>
                    <input type="tel" placeholder="+91" className="w-full bg-navy-900/50 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-slate-600 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-light" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Service Required</label>
                    <select className="w-full bg-navy-900/50 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-light appearance-none">
                      <option>Personal Loan</option>
                      <option>Business Loan</option>
                      <option>Home Loan</option>
                      <option>Credit Card</option>
                      <option>Insurance</option>
                      <option>GST Support</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Message (Optional)</label>
                  <textarea rows={4} placeholder="How can we help you?" className="w-full bg-navy-900/50 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-slate-600 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-all font-light"></textarea>
                </div>
                <button type="submit" className="w-full bg-gradient-to-r from-gold-500 to-gold-400 hover:from-gold-400 hover:to-gold-300 text-navy-950 font-bold py-4 rounded-xl transition-all shadow-lg text-sm uppercase tracking-wide">
                  Submit Details
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-900 border-t border-white/10 pt-20 pb-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="lg:col-span-2">
               <div className="flex items-center gap-2 mb-6">
                <div className="w-8 h-8 rounded bg-gold-500 flex items-center justify-center text-navy-900">
                  <Landmark className="w-5 h-5" />
                </div>
                <div className="font-serif text-xl font-bold text-white">
                  NEXORA
                  <span className="text-gold-500 block font-light text-sm italic">
                    Corporate Ventures
                  </span>
                </div>
              </div>
              <p className="text-slate-400 max-w-md leading-relaxed mb-8">
                Your trusted financial partner offering strategic consulting and facilitating seamless access to premier banking and financial solutions across India.
              </p>
              <div className="text-slate-300 space-y-2">
                <p className="flex items-center gap-2"><Phone className="w-4 h-4 text-gold-500" /> +91 70779 26565</p>
                <p className="flex items-center gap-2"><Mail className="w-4 h-4 text-gold-500" /> nexoracorporateventures@gmail.com</p>
              </div>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Quick Links</h4>
              <ul className="space-y-3">
                {navLinks.map(link => (
                  <li key={link.name}>
                    <a href={link.href} className="text-slate-400 hover:text-gold-500 transition-colors">{link.name}</a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-white mb-6">Services</h4>
              <ul className="space-y-3">
                {['Personal Loan', 'Business Loan', 'Home Loan', 'Credit Cards', 'Insurance', 'GST Services'].map(item => (
                  <li key={item}>
                    <a href="#services" className="text-slate-400 hover:text-gold-500 transition-colors">{item}</a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8 mt-8">
            <div className="bg-navy-800 p-6 rounded-lg mb-8 text-center text-sm md:text-base text-slate-400 leading-relaxed border border-white/5">
              <strong className="text-white block mb-2">Important Disclaimer:</strong>
              "Nexora Corporate Ventures is a financial consultancy and service facilitator. We are not a bank or NBFC. Loan approvals are subject to eligibility and approval by respective financial institutions."
            </div>
            
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
              <p>&copy; {new Date().getFullYear()} Nexora Corporate Ventures. All rights reserved.</p>
              <div className="flex gap-4 border-l border-white/10 pl-4 items-center">
                <a href="#" className="hover:text-gold-500 transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-gold-500 transition-colors">Terms of Service</a>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button */}
      <a 
        href="https://wa.me/917077926565" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-[0_4px_20px_rgba(37,211,102,0.4)] hover:scale-110 hover:shadow-[0_8px_30px_rgba(37,211,102,0.6)] transition-all flex items-center justify-center group"
      >
        <div className="absolute inset-0 rounded-full border-2 border-[#25D366] animate-ping opacity-20"></div>
        <MessageCircle className="w-8 h-8 relative z-10" />
        <span className="absolute -top-12 right-0 bg-white text-navy-900 text-xs font-bold px-3 py-2 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap hidden md:block">
          Chat with us!
        </span>
      </a>

    </div>
  );
}
